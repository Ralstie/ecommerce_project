"""URL routes for the eCommerce REST API."""

from django.urls import path

from . import views

urlpatterns = [
    path('stores/', views.api_stores, name='api_stores'),
    path('stores/<int:store_id>/', views.api_store_detail, name='api_store_detail'),
    path('products/', views.api_products, name='api_products'),
    path('products/<int:product_id>/', views.api_product_detail, name='api_product_detail'),
    path('reviews/', views.api_reviews, name='api_reviews'),
    path('reviews/<int:review_id>/', views.api_review_detail, name='api_review_detail'),
]
