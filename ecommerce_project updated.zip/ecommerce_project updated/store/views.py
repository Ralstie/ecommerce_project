from django.contrib.auth import login
from django.contrib.auth.models import User
from django.contrib.auth.decorators import login_required
from django.shortcuts import (
    render,
    redirect,
    get_object_or_404
)
from django.db import transaction

from .models import (
    UserProfile,
    Store,
    Product,
    Order,
    OrderItem,
    Review
)

from .forms import (
    RegistrationForm,
    StoreForm,
    ProductForm,
    ReviewForm
)

from rest_framework.decorators import (
    api_view,
    permission_classes,
    authentication_classes,
)
from rest_framework.authentication import (
    TokenAuthentication,
    SessionAuthentication,
)
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework import status

from .serializers import (
    StoreSerializer,
    ProductSerializer,
    ReviewSerializer,
)


# =============
# HOME PAGE
# =============

def home(request):
    """Send authenticated users to the page appropriate to their role."""
    if request.user.is_authenticated:
        profile = UserProfile.objects.filter(user=request.user).first()
        if profile and profile.role == 'VENDOR':
            return redirect('vendor_dashboard')
        return redirect('product_list')
    return render(request, 'store/home.html')


# ===================
# USER REGISTRATION
# ===================

def register(request):

    'Register a new buyer or vendor and log the user in.'
    if request.method == 'POST':

        form = RegistrationForm(
            request.POST
        )

        if form.is_valid():

            user = form.save()

            login(request, user)

            profile = UserProfile.objects.get(user=user)
            if profile.role == 'VENDOR':
                return redirect('vendor_dashboard')
            return redirect('product_list')

    else:

        form = RegistrationForm()

    return render(
        request,
        'store/register.html',
        {
            'form': form
        }
    )


# ===================
# VENDOR DASHBOARD
# ===================

@login_required
def vendor_dashboard(request):

    'Display the authenticated vendor’s stores.'
    profile = get_object_or_404(
        UserProfile,
        user=request.user
    )

    if profile.role != 'VENDOR':

        return redirect('home')

    stores = Store.objects.filter(
        vendor=request.user
    )

    return render(
        request,
        'store/vendor_dashboard.html',
        {
            'stores': stores
        }
    )


# ==============
# CREATE STORE
# ==============

@login_required
def store_create(request):

    'Allow an authenticated vendor to create a store they own.'
    profile = get_object_or_404(
        UserProfile,
        user=request.user
    )

    if profile.role != 'VENDOR':

        return redirect('home')

    if request.method == 'POST':

        form = StoreForm(
            request.POST
        )

        if form.is_valid():

            store = form.save(
                commit=False
            )

            store.vendor = request.user

            store.save()

            return redirect(
                'vendor_dashboard'
            )

    else:

        form = StoreForm()

    return render(
        request,
        'store/store_form.html',
        {
            'form': form
        }
    )


# ============
# EDIT STORE
# ============

@login_required
def store_edit(request, store_id):

    'Allow an authenticated vendor to edit one of their own stores.'
    profile = get_object_or_404(
        UserProfile,
        user=request.user
    )

    if profile.role != 'VENDOR':

        return redirect('home')

    store = get_object_or_404(
        Store,
        id=store_id,
        vendor=request.user
    )

    if request.method == 'POST':

        form = StoreForm(
            request.POST,
            instance=store
        )

        if form.is_valid():

            form.save()

            return redirect(
                'vendor_dashboard'
            )

    else:

        form = StoreForm(
            instance=store
        )

    return render(
        request,
        'store/store_form.html',
        {
            'form': form,
            'store': store
        }
    )


# ==============
# DELETE STORE
# ==============

@login_required
def store_delete(request, store_id):

    'Allow an authenticated vendor to delete one of their own stores.'
    profile = get_object_or_404(
        UserProfile,
        user=request.user
    )

    if profile.role != 'VENDOR':

        return redirect('home')

    store = get_object_or_404(
        Store,
        id=store_id,
        vendor=request.user
    )

    if request.method == 'POST':

        store.delete()

        return redirect(
            'vendor_dashboard'
        )

    return render(
        request,
        'store/store_confirm_delete.html',
        {
            'store': store
        }
    )


# ================
# VENDOR PRODUCTS
# ================

@login_required
def vendor_products(request, store_id):

    'Display the products belonging to one of the vendor’s stores.'
    profile = get_object_or_404(
        UserProfile,
        user=request.user
    )

    if profile.role != 'VENDOR':

        return redirect('home')

    store = get_object_or_404(
        Store,
        id=store_id,
        vendor=request.user
    )

    products = Product.objects.filter(
        store=store
    )

    return render(
        request,
        'store/vendor_products.html',
        {
            'store': store,
            'products': products
        }
    )


# ===============
# CREATE PRODUCT
# ===============

@login_required
def product_create(request, store_id):

    'Allow an authenticated vendor to add a product to their own store.'
    profile = get_object_or_404(
        UserProfile,
        user=request.user
    )

    if profile.role != 'VENDOR':

        return redirect('home')

    store = get_object_or_404(
        Store,
        id=store_id,
        vendor=request.user
    )

    if request.method == 'POST':

        form = ProductForm(
            request.POST,
            request.FILES
        )

        if form.is_valid():

            product = form.save(
                commit=False
            )

            product.store = store

            product.save()

            return redirect(
                'vendor_products',
                store_id=store.id
            )

    else:

        form = ProductForm()

    return render(
        request,
        'store/product_form.html',
        {
            'form': form,
            'store': store
        }
    )


# ===================
# BUYER PRODUCT LIST
# ===================

def product_list(request):

    'Display all products available to buyers.'
    products = Product.objects.all()

    return render(
        request,
        'store/product_list.html',
        {
            'products': products
        }
    )


# ================
# PRODUCT DETAILS# ================

def product_detail(request, product_id):

    'Display the details of one product.'
    product = get_object_or_404(
        Product,
        id=product_id
    )

    return render(
        request,
        'store/product_detail.html',
        {
            'product': product
        }
    )


# =================
# PUBLIC DISCOVERY
# =================

def vendor_list(request):
    """List vendors that have stores."""
    vendors = User.objects.filter(
        userprofile__role='VENDOR',
        stores__isnull=False
    ).distinct().order_by('username')
    return render(request, 'store/vendor_list.html', {'vendors': vendors})


def vendor_stores(request, vendor_id):
    """List stores belonging to a selected vendor."""
    vendor = get_object_or_404(User, id=vendor_id, userprofile__role='VENDOR')
    stores = Store.objects.filter(vendor=vendor).order_by('name')
    return render(request, 'store/vendor_stores.html',
                  {'vendor': vendor, 'stores': stores})


def store_list(request):
    """List all stores available in the marketplace."""
    stores = Store.objects.select_related('vendor').order_by('name')
    return render(request, 'store/store_list.html', {'stores': stores})


def store_products(request, store_id):
    """List products belonging to one selected store."""
    store = get_object_or_404(Store, id=store_id)
    products = Product.objects.filter(store=store).order_by('name')
    return render(request, 'store/store_products.html',
                  {'store': store, 'products': products})


# ============
# ADD TO CART
# ============

@login_required
def add_to_cart(request, product_id):
    """Add a requested quantity without allowing the cart to exceed stock."""
    product = get_object_or_404(Product, id=product_id)

    if request.method != 'POST':
        return redirect('product_detail', product_id=product.id)

    try:
        quantity = int(request.POST.get('quantity', 1))
    except (TypeError, ValueError):
        quantity = 0

    from django.contrib import messages
    if quantity < 1:
        messages.error(request, 'Please enter a quantity of at least 1.')
        return redirect('product_detail', product_id=product.id)

    cart_data = request.session.get('cart', {})
    key = str(product.id)
    current = int(cart_data.get(key, 0))

    if current + quantity > product.stock:
        messages.error(
            request,
            f'Only {product.stock} unit(s) of {product.name} are available. '
            f'You already have {current} in your cart.'
        )
        return redirect('product_detail', product_id=product.id)

    cart_data[key] = current + quantity
    request.session['cart'] = cart_data
    request.session.modified = True
    return redirect('cart')


@login_required
def update_cart_item(request, product_id):
    """Update a cart item's quantity, respecting current stock."""
    product = get_object_or_404(Product, id=product_id)

    if request.method == 'POST':
        try:
            quantity = int(request.POST.get('quantity', 0))
        except (TypeError, ValueError):
            quantity = -1

        cart_data = request.session.get('cart', {})
        key = str(product.id)

        from django.contrib import messages
        if quantity <= 0:
            cart_data.pop(key, None)
        elif quantity > product.stock:
            messages.error(
                request,
                f'Only {product.stock} unit(s) of {product.name} are available.'
            )
        else:
            cart_data[key] = quantity

        request.session['cart'] = cart_data
        request.session.modified = True

    return redirect('cart')


@login_required
def remove_cart_item(request, product_id):
    """Remove an item from the current cart."""
    if request.method == 'POST':
        cart_data = request.session.get('cart', {})
        cart_data.pop(str(product_id), None)
        request.session['cart'] = cart_data
        request.session.modified = True
    return redirect('cart')


# ======
# CART
# ======

@login_required
def cart(request):
    """Display the current session cart and calculate its total."""
    cart_data = request.session.get('cart', {})
    products = Product.objects.filter(id__in=cart_data.keys())

    clean_cart = {}
    cart_items = []
    total = 0

    for product in products:
        quantity = min(int(cart_data.get(str(product.id), 0)), product.stock)
        if quantity > 0:
            clean_cart[str(product.id)] = quantity
            item_total = product.price * quantity
            total += item_total
            cart_items.append({
                'product': product,
                'quantity': quantity,
                'item_total': item_total,
            })

    if clean_cart != cart_data:
        request.session['cart'] = clean_cart
        request.session.modified = True

    return render(request, 'store/cart.html',
                  {'cart_items': cart_items, 'total': total})


# =========
# CHECKOUT
# =========

@login_required
@transaction.atomic
def checkout(request):

    'Create an order from the current cart and reduce product stock.'
    cart = request.session.get(
        'cart',
        {}
    )

    if not cart:

        return redirect('cart')

    products = Product.objects.select_for_update().filter(
        id__in=cart.keys()
    )

    total = 0

    for product in products:

        quantity = cart[
            str(product.id)
        ]

        if quantity > product.stock:

            return render(
                request,
                'store/checkout_error.html',
                {
                    'product': product
                }
            )

        total += (
            product.price * quantity
        )

    order = Order.objects.create(
        buyer=request.user,
        total=total,
        status='Completed'
    )

    for product in products:

        quantity = cart[
            str(product.id)
        ]

        OrderItem.objects.create(
            order=order,
            product=product,
            quantity=quantity,
            price=product.price
        )

        product.stock -= quantity

        product.save()

    request.session['cart'] = {}

    request.session.modified = True

    return redirect(
        'order_success',
        order_id=order.id
    )


# ==============
# ORDER SUCCESS
# ==============

@login_required
def order_success(request, order_id):

    'Display an order confirmation for the authenticated buyer.'
    order = get_object_or_404(
        Order,
        id=order_id,
        buyer=request.user
    )

    return render(
        request,
        'store/order_success.html',
        {
            'order': order
        }
    )


# ===========
# ADD REVIEW
# ===========

@login_required
def add_review(request, product_id):

    'Allow a buyer to submit a review for a product.'
    product = get_object_or_404(
        Product,
        id=product_id
    )

    profile = get_object_or_404(UserProfile, user=request.user)
    if profile.role != 'BUYER':
        from django.contrib import messages
        messages.error(request, 'Only buyers can submit reviews.')
        return redirect('product_detail', product_id=product.id)

    if request.method == 'POST':

        form = ReviewForm(
            request.POST
        )

        if form.is_valid():

            review = form.save(
                commit=False
            )

            review.buyer = request.user

            review.product = product

            purchased = OrderItem.objects.filter(
                order__buyer=request.user,
                product=product
            ).exists()

            review.verified = purchased

            review.save()

            return redirect(
                'product_detail',
                product_id=product.id
            )

    else:

        form = ReviewForm()

    return render(
        request,
        'store/review_form.html',
        {
            'form': form,
            'product': product
        }
    )


# =========================
# VENDOR PRODUCT CRUD
# =========================

@login_required
def product_edit(request, product_id):
    """Allow a vendor to edit a product in one of their stores."""
    profile = get_object_or_404(UserProfile, user=request.user)
    if profile.role != 'VENDOR':
        return redirect('home')
    product = get_object_or_404(Product, id=product_id, store__vendor=request.user)

    if request.method == 'POST':
        form = ProductForm(request.POST, request.FILES, instance=product)
        if form.is_valid():
            form.save()
            return redirect('vendor_products', store_id=product.store.id)
    else:
        form = ProductForm(instance=product)

    return render(request, 'store/product_form.html',
                  {'form': form, 'store': product.store, 'product': product})


@login_required
def product_delete(request, product_id):
    """Allow a vendor to delete a product in one of their stores."""
    profile = get_object_or_404(UserProfile, user=request.user)
    if profile.role != 'VENDOR':
        return redirect('home')
    product = get_object_or_404(Product, id=product_id, store__vendor=request.user)

    if request.method == 'POST':
        store_id = product.store.id
        product.delete()
        return redirect('vendor_products', store_id=store_id)

    return render(request, 'store/product_confirm_delete.html',
                  {'product': product})



# =========================
# REVIEW CRUD
# =========================

@login_required
def edit_review(request, review_id):
    """Allow a buyer to edit their own review."""
    review = get_object_or_404(Review, id=review_id, buyer=request.user)
    if request.method == 'POST':
        form = ReviewForm(request.POST, instance=review)
        if form.is_valid():
            form.save()
            return redirect('product_detail', product_id=review.product.id)
    else:
        form = ReviewForm(instance=review)
    return render(request, 'store/review_form.html',
                  {'form': form, 'product': review.product, 'review': review})


@login_required
def delete_review(request, review_id):
    """Allow a buyer to delete their own review."""
    review = get_object_or_404(Review, id=review_id, buyer=request.user)
    if request.method == 'POST':
        product_id = review.product.id
        review.delete()
        return redirect('product_detail', product_id=product_id)
    return render(request, 'store/review_confirm_delete.html', {'review': review})


# =========================
# REST API
# =========================

def _is_vendor(user):
    """Return whether the authenticated user has a vendor profile."""
    return UserProfile.objects.filter(user=user, role='VENDOR').exists()


def _owns_store(user, store):
    return store.vendor_id == user.id


@api_view(['GET', 'POST'])
@authentication_classes([TokenAuthentication, SessionAuthentication])
@permission_classes([IsAuthenticated])
def api_stores(request):
    """List stores; vendors may create stores."""
    if request.method == 'GET':
        stores = Store.objects.select_related('vendor').all()
        return Response(StoreSerializer(
            stores, many=True, context={'request': request}
        ).data)

    if not _is_vendor(request.user):
        return Response(
            {'detail': 'Only authenticated vendors can create stores.'},
            status=status.HTTP_403_FORBIDDEN
        )

    serializer = StoreSerializer(data=request.data, context={'request': request})
    if serializer.is_valid():
        serializer.save(vendor=request.user)
        return Response(serializer.data, status=status.HTTP_201_CREATED)
    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


@api_view(['GET', 'PUT', 'PATCH', 'DELETE'])
@authentication_classes([TokenAuthentication, SessionAuthentication])
@permission_classes([IsAuthenticated])
def api_store_detail(request, store_id):
    """Retrieve, update or delete a store owned by the authenticated vendor."""
    store = get_object_or_404(Store, id=store_id)

    if request.method == 'GET':
        return Response(StoreSerializer(store, context={'request': request}).data)

    if not _owns_store(request.user, store):
        return Response(
            {'detail': 'You can only modify your own stores.'},
            status=status.HTTP_403_FORBIDDEN
        )

    if request.method == 'DELETE':
        store.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)

    serializer = StoreSerializer(
        store, data=request.data, partial=request.method == 'PATCH',
        context={'request': request}
    )
    if serializer.is_valid():
        serializer.save()
        return Response(serializer.data)
    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


@api_view(['GET', 'POST'])
@authentication_classes([TokenAuthentication, SessionAuthentication])
@permission_classes([IsAuthenticated])
def api_products(request):
    """List products; vendors may create products in their own stores."""
    if request.method == 'GET':
        products = Product.objects.select_related('store').all()
        return Response(ProductSerializer(
            products, many=True, context={'request': request}
        ).data)

    if not _is_vendor(request.user):
        return Response(
            {'detail': 'Only authenticated vendors can create products.'},
            status=status.HTTP_403_FORBIDDEN
        )

    serializer = ProductSerializer(data=request.data, context={'request': request})
    if serializer.is_valid():
        serializer.save()
        return Response(serializer.data, status=status.HTTP_201_CREATED)
    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


@api_view(['GET', 'PUT', 'PATCH', 'DELETE'])
@authentication_classes([TokenAuthentication, SessionAuthentication])
@permission_classes([IsAuthenticated])
def api_product_detail(request, product_id):
    """Retrieve, update or delete a product owned through the vendor's store."""
    product = get_object_or_404(Product, id=product_id)

    if request.method == 'GET':
        return Response(ProductSerializer(
            product, context={'request': request}
        ).data)

    if not _owns_store(request.user, product.store):
        return Response(
            {'detail': 'You can only modify products in your own stores.'},
            status=status.HTTP_403_FORBIDDEN
        )

    if request.method == 'DELETE':
        product.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)

    serializer = ProductSerializer(
        product, data=request.data, partial=request.method == 'PATCH',
        context={'request': request}
    )
    if serializer.is_valid():
        serializer.save()
        return Response(serializer.data)
    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


@api_view(['GET', 'POST'])
@authentication_classes([TokenAuthentication, SessionAuthentication])
@permission_classes([IsAuthenticated])
def api_reviews(request):
    """Vendors retrieve reviews; buyers create their own reviews."""
    profile = get_object_or_404(UserProfile, user=request.user)

    if request.method == 'GET':
        if profile.role != 'VENDOR':
            return Response(
                {'detail': 'Only vendors can retrieve reviews.'},
                status=status.HTTP_403_FORBIDDEN
            )
        reviews = Review.objects.select_related('buyer', 'product').all()
        return Response(ReviewSerializer(
            reviews, many=True, context={'request': request}
        ).data)

    if profile.role != 'BUYER':
        return Response(
            {'detail': 'Only buyers can create reviews.'},
            status=status.HTTP_403_FORBIDDEN
        )

    serializer = ReviewSerializer(data=request.data, context={'request': request})
    if serializer.is_valid():
        product = serializer.validated_data['product']
        purchased = OrderItem.objects.filter(
            order__buyer=request.user, product=product
        ).exists()
        review = serializer.save(buyer=request.user, verified=purchased)
        return Response(
            ReviewSerializer(review, context={'request': request}).data,
            status=status.HTTP_201_CREATED
        )
    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


@api_view(['GET', 'PUT', 'PATCH', 'DELETE'])
@authentication_classes([TokenAuthentication, SessionAuthentication])
@permission_classes([IsAuthenticated])
def api_review_detail(request, review_id):
    """Retrieve, update or delete a review owned by the authenticated buyer."""
    review = get_object_or_404(Review, id=review_id)

    if request.method == 'GET':
        return Response(ReviewSerializer(
            review, context={'request': request}
        ).data)

    if review.buyer_id != request.user.id:
        return Response(
            {'detail': 'You can only modify your own reviews.'},
            status=status.HTTP_403_FORBIDDEN
        )

    if request.method == 'DELETE':
        review.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)

    serializer = ReviewSerializer(
        review, data=request.data, partial=request.method == 'PATCH',
        context={'request': request}
    )
    if serializer.is_valid():
        # Verification is controlled by the server, not the client.
        review = serializer.save(verified=review.verified)
        return Response(ReviewSerializer(
            review, context={'request': request}
        ).data)
    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
