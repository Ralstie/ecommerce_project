# Task 19 – eCommerce API Sequence Diagram

This sequence diagram covers the CRUD interactions for the three required API
entities: **Stores, Products and Reviews**. Authentication is shown because
the API requires an authenticated user, and ownership/role checks are applied
before write operations.

```mermaid
sequenceDiagram
    autonumber
    actor User
    participant API as Django REST API
    participant Auth as Authentication
    participant DB as MySQL Database

    Note over User,DB: STORES CRUD

    User->>API: GET /api/stores/
    API->>Auth: Check authentication
    Auth-->>API: Authenticated
    API->>DB: SELECT stores
    DB-->>API: Store records
    API-->>User: 200 OK + stores

    User->>API: POST /api/stores/ {name, description}
    API->>Auth: Check authentication and VENDOR role
    Auth-->>API: Vendor authenticated
    API->>DB: INSERT store owned by vendor
    DB-->>API: Created store
    API-->>User: 201 Created

    User->>API: GET /api/stores/{id}/
    API->>DB: SELECT store
    DB-->>API: Store
    API-->>User: 200 OK + store

    User->>API: PUT/PATCH /api/stores/{id}/
    API->>Auth: Check authentication and store ownership
    Auth-->>API: Owner verified
    API->>DB: UPDATE store
    DB-->>API: Updated store
    API-->>User: 200 OK + store

    User->>API: DELETE /api/stores/{id}/
    API->>Auth: Check authentication and store ownership
    Auth-->>API: Owner verified
    API->>DB: DELETE store
    DB-->>API: Deletion confirmed
    API-->>User: 204 No Content

    Note over User,DB: PRODUCTS CRUD

    User->>API: GET /api/products/
    API->>Auth: Check authentication
    Auth-->>API: Authenticated
    API->>DB: SELECT products
    DB-->>API: Product records
    API-->>User: 200 OK + products

    User->>API: POST /api/products/ {store, product data}
    API->>Auth: Check authentication and VENDOR role
    Auth-->>API: Vendor authenticated
    API->>DB: Verify store belongs to vendor
    DB-->>API: Ownership confirmed
    API->>DB: INSERT product
    DB-->>API: Created product
    API-->>User: 201 Created

    User->>API: GET /api/products/{id}/
    API->>DB: SELECT product
    DB-->>API: Product
    API-->>User: 200 OK + product

    User->>API: PUT/PATCH /api/products/{id}/
    API->>Auth: Check authentication and product ownership
    Auth-->>API: Owner verified
    API->>DB: UPDATE product
    DB-->>API: Updated product
    API-->>User: 200 OK + product

    User->>API: DELETE /api/products/{id}/
    API->>Auth: Check authentication and product ownership
    Auth-->>API: Owner verified
    API->>DB: DELETE product
    DB-->>API: Deletion confirmed
    API-->>User: 204 No Content

    Note over User,DB: REVIEWS CRUD

    User->>API: GET /api/reviews/
    API->>Auth: Check authentication and VENDOR role
    Auth-->>API: Vendor authenticated
    API->>DB: SELECT reviews
    DB-->>API: Review records + verified status
    API-->>User: 200 OK + reviews

    User->>API: POST /api/reviews/ {product, rating, comment}
    API->>Auth: Check authentication and BUYER role
    Auth-->>API: Buyer authenticated
    API->>DB: Check buyer purchased product
    DB-->>API: Purchase result
    API->>DB: INSERT review with verified/unverified status
    DB-->>API: Created review
    API-->>User: 201 Created + verification status

    User->>API: GET /api/reviews/{id}/
    API->>DB: SELECT review
    DB-->>API: Review
    API-->>User: 200 OK + review

    User->>API: PUT/PATCH /api/reviews/{id}/
    API->>Auth: Check authentication and review ownership
    Auth-->>API: Owner verified
    API->>DB: UPDATE review
    DB-->>API: Updated review
    API-->>User: 200 OK + review

    User->>API: DELETE /api/reviews/{id}/
    API->>Auth: Check authentication and review ownership
    Auth-->>API: Owner verified
    API->>DB: DELETE review
    DB-->>API: Deletion confirmed
    API-->>User: 204 No Content
```

## CRUD summary

| Entity | Create | Retrieve | Update | Delete |
|---|---|---|---|---|
| Stores | Vendor | Authenticated user | Store owner | Store owner |
| Products | Vendor | Authenticated user | Store owner | Store owner |
| Reviews | Buyer | Vendor / review owner | Review owner | Review owner |

The verification status of a review is calculated by the server from the
buyer's purchase history and is not accepted as a client-controlled field.
