# E-Commerce Marketplace

A Django-based e-commerce marketplace developed as part of Task 19 - Django – eCommerce Application Part 2.

The application supports buyer and vendor accounts, vendor stores and products, shopping cart and checkout functionality, product reviews, and a protected Django REST Framework API.

## Features

- User registration with BUYER and VENDOR roles
- Vendor dashboard
- Vendor store creation, editing and deletion
- Vendor product creation
- Product listings and details
- Session-based shopping cart
- Checkout and orders
- Product reviews with purchase verification
- Login, logout and password reset
- REST API using Django REST Framework
- Token authentication for API clients
- Vendor-only API permissions for creating stores, adding products and retrieving reviews

## Technologies Used

- Python 3.14
- Django 6.1
- Django REST Framework 3.18
- MySQL
- HTML, CSS and Bootstrap
- Pillow
- mysqlclient

## Project Structure

```text
ecommerce_project/
├── manage.py
├── requirements.txt
├── README.md
├── Planning/
├── ecommerce_project/
│   ├── settings.py
│   ├── urls.py
│   ├── asgi.py
│   └── wsgi.py
└── store/
    ├── models.py
    ├── forms.py
    ├── serializers.py
    ├── views.py
    ├── api_urls.py
    ├── urls.py
    ├── tests.py
    ├── migrations/
    └── templates/
```

## Installation

### 1. Clone the repository

```bash
git clone <your-github-repository-url>
cd ecommerce_project
```

### 2. Create a virtual environment

Windows:

```bash
python -m venv venv
venv\Scripts\activate
```

macOS/Linux:

```bash
python3 -m venv venv
source venv/bin/activate
```

### 3. Install dependencies

```bash
python -m pip install --upgrade pip
pip install -r requirements.txt
```

### 4. Create and configure the MySQL database

Make sure the MySQL server is running. Open a terminal and log in to MySQL:

```bash
mysql -u root -p
```

Enter your MySQL root password when prompted. Then create the application database:

```sql
CREATE DATABASE ecommerce_db;
```

You can confirm it exists with:

```sql
SHOW DATABASES;
```

Then exit MySQL:

```sql
exit;
```

Before starting Django, update the database environment variables below with **your own MySQL values**. In particular, replace `your_mysql_password` with the password for your MySQL `root` account. If you created a different database name or use a different MySQL user, update those values too.

Set the following environment variables before running Django:

Windows Command Prompt:

```cmd
set MYSQL_DATABASE=ecommerce_db
set MYSQL_USER=root
set MYSQL_PASSWORD=your_mysql_password
set MYSQL_HOST=localhost
set MYSQL_PORT=3306
```

PowerShell:

```powershell
$env:MYSQL_DATABASE="ecommerce_db"
$env:MYSQL_USER="root"
$env:MYSQL_PASSWORD="your_mysql_password"
$env:MYSQL_HOST="localhost"
$env:MYSQL_PORT="3306"
```

The project no longer stores a real database password in `settings.py`.

### 5. Run migrations

```bash
python manage.py makemigrations
python manage.py migrate
```

### 6. Create an administrator

```bash
python manage.py createsuperuser
```

### 7. Start the development server

```bash
python manage.py runserver
```

Open the application at:

```text
http://127.0.0.1:8000/
```

## Running Tests

Run the complete test suite with:

```bash
python manage.py test
```

The tests include:

- Store creation
- Vendor store creation through the API
- Vendor product creation through the API
- Rejection of unauthenticated API writes
- Retrieval of product reviews by an authenticated vendor

## Website Navigation

After registration and login, the application sends each role to the appropriate starting page:

- **Vendor** → Vendor Dashboard
- **Buyer** → Products

The main navigation is role-specific:

- **Buyer** → Vendors, Stores, Products and Cart
- **Vendor** → Vendor Dashboard only; buyer shopping links are hidden

Vendors can create, edit and delete their own stores and products. On vendor product pages, products have **Edit** and **Delete** controls instead of **Add to Cart**. Vendors cannot use the cart or checkout, including by entering the URLs directly.

Buyers can browse stores and products, add products to their cart, checkout and submit reviews. Reviews display whether they are **Verified** (the buyer purchased the product) or **Unverified**.

## Email Setup

The application sends two types of email:

1. **Order invoices** — sent to the buyer after a successful checkout.
2. **Password-reset emails** — sent by Django's built-in password reset views.

Email credentials are **not stored in the source code**. Configure the email backend with environment variables.

### Local development without SMTP

By default, the project uses Django's console email backend. This means invoice and password-reset emails are printed in the terminal running `python manage.py runserver`.

No Gmail account is required for this mode:

```powershell
$env:EMAIL_BACKEND="django.core.mail.backends.console.EmailBackend"
```

Restart the Django development server after changing environment variables.

### Gmail SMTP setup

To send real emails, use a Gmail account with **2-Step Verification** enabled and create a Gmail **App Password**. Do not use the normal Gmail account password.

Set the following environment variables in PowerShell:

```powershell
$env:EMAIL_BACKEND="django.core.mail.backends.smtp.EmailBackend"
$env:EMAIL_HOST="smtp.gmail.com"
$env:EMAIL_PORT="587"
$env:EMAIL_USE_TLS="True"
$env:EMAIL_HOST_USER="your_email@gmail.com"
$env:EMAIL_HOST_PASSWORD="your_16_character_app_password"
$env:DEFAULT_FROM_EMAIL="your_email@gmail.com"
```

For Windows Command Prompt:

```cmd
set EMAIL_BACKEND=django.core.mail.backends.smtp.EmailBackend
set EMAIL_HOST=smtp.gmail.com
set EMAIL_PORT=587
set EMAIL_USE_TLS=True
set EMAIL_HOST_USER=your_email@gmail.com
set EMAIL_HOST_PASSWORD=your_16_character_app_password
set DEFAULT_FROM_EMAIL=your_email@gmail.com
```

Replace the example values with your own Gmail address and App Password.

### Testing invoice emails

1. Register or create a **Buyer** account with a valid email address.
2. Log in as the buyer.
3. Add an in-stock product to the cart.
4. Complete checkout.
5. The application creates the order and sends an invoice to the buyer's email address.
6. The order-success page confirms that the invoice will be sent.

If the console backend is being used, inspect the terminal running Django to see the email contents.

### Testing password reset

1. Open:

```text
http://127.0.0.1:8000/password-reset/
```

2. Enter the email address of an existing user.
3. Submit the form.
4. Django sends the password-reset email.
5. With the console backend, copy the reset link from the terminal.
6. Open the link and set a new password.

Password-reset emails are only sent when the entered address belongs to a user with an email address.

### Important security notes

- Never commit `EMAIL_HOST_PASSWORD` or a Gmail App Password to GitHub.
- Do not place real SMTP credentials directly in `settings.py`.
- For production, use environment variables or a secure secrets manager.
- The console backend is intended for development/testing; use an SMTP or transactional email provider for production.

## REST API

The API is implemented with Django REST Framework.

The API uses token authentication. Authentication is required for the API endpoints, and only users with a VENDOR profile may create stores, add products, or retrieve reviews.

### Obtain an API token

First create a vendor account through the website or Django admin.

Then request a token:

```http
POST /api-token-auth/
```

Example JSON/form data:

```text
username=vendor
password=your_password
```

A successful response contains:

```json
{
    "token": "your-token-value"
}
```

Include the token in subsequent API requests:

```http
Authorization: Token your-token-value
```

### Stores

The Stores API supports CRUD operations:

```text
GET    /api/stores/              List stores
POST   /api/stores/              Create a store (vendor)
GET    /api/stores/<id>/         Retrieve one store
PUT    /api/stores/<id>/         Replace a store (owner)
PATCH  /api/stores/<id>/         Update a store (owner)
DELETE /api/stores/<id>/         Delete a store (owner)
```

List stores:

```http
GET /api/stores/
```

Create a store as an authenticated vendor:

```http
POST /api/stores/
```

Example JSON:

```json
{
    "name": "Anime Store",
    "description": "Anime figures and collectibles."
}
```

The authenticated vendor is automatically assigned as the store owner.

### Products

The Products API supports CRUD operations:

```text
GET    /api/products/            List products
POST   /api/products/            Create a product (vendor)
GET    /api/products/<id>/       Retrieve one product
PUT    /api/products/<id>/       Replace a product (owner)
PATCH  /api/products/<id>/       Update a product (owner)
DELETE /api/products/<id>/       Delete a product (owner)
```

List products:

```http
GET /api/products/
```

Create a product as an authenticated vendor:

```http
POST /api/products/
```

Example JSON:

```json
{
    "store": 1,
    "name": "Anime Figure",
    "description": "Collectible anime figure.",
    "price": "299.99",
    "stock": 10
}
```

A vendor can only add products to a store that belongs to that vendor.

### Reviews

The Reviews API supports CRUD operations:

```text
GET    /api/reviews/             Retrieve reviews (vendor)
POST   /api/reviews/             Create a review (buyer)
GET    /api/reviews/<id>/        Retrieve one review
PUT    /api/reviews/<id>/        Update own review
PATCH  /api/reviews/<id>/        Partially update own review
DELETE /api/reviews/<id>/        Delete own review
```

Retrieve product reviews as an authenticated vendor:

```http
GET /api/reviews/
```

Example response:

```json
[
    {
        "id": 1,
        "buyer": "buyer1",
        "product": 1,
        "product_name": "Anime Figure",
        "rating": 5,
        "comment": "Excellent product.",
        "verified": true,
        "created_at": "2026-09-01T10:00:00Z"
    }
]
```

## API Security

The API uses Django REST Framework authentication and permissions.

- Unauthenticated clients cannot perform protected API operations.
- Vendor checks are performed before creating stores or products.
- A vendor cannot add a product to another vendor's store.
- API serializers prevent clients from assigning a different vendor as the store owner.
- Review retrieval is restricted to authenticated vendors.
- Database credentials are read from environment variables instead of being stored in source code.

## Useful URLs

Website:

```text
http://127.0.0.1:8000/
```

Admin:

```text
http://127.0.0.1:8000/admin/
```

API stores:

```text
http://127.0.0.1:8000/api/stores/
```

API products:

```text
http://127.0.0.1:8000/api/products/
```

API reviews:

```text
http://127.0.0.1:8000/api/reviews/
```

API token:

```text
http://127.0.0.1:8000/api-token-auth/
```

Browsable API authentication:

```text
http://127.0.0.1:8000/api-auth/login/
```

## Notes

Do not commit passwords, API tokens, secret keys, database credentials, or other sensitive information to GitHub.

For production deployment, `DEBUG` should be disabled and a secure `DJANGO_SECRET_KEY` should be supplied through an environment variable.
